<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "12345", "supercar");

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Définir le jeu de caractères
$conn->set_charset("utf8");
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Images</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<h2>Administration des Voitures</h2>

<table border="1" width="100%">
    <tr>
        <th>ID</th>
        <th>Marque</th>
        <th>Model</th>
        <th>Description</th>
        <th>Prix</th>
        <th>Vitesse</th>
        <th>Puissance</th>
        <th>Nombre de vue</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    <?php
    // Récupération de toutes les données de la table 'voiture'
    $resultVoitures = $conn->query("SELECT * FROM details_voitures");

    // Vérifier si des données existent
    if ($resultVoitures->num_rows > 0) {
        while ($row = $resultVoitures->fetch_assoc()) {
            $voitureId = $row['id'];
            $marque = htmlspecialchars($row['marque']);
            $model = htmlspecialchars($row['model']);
            $description = htmlspecialchars($row['description']);
            $prix = htmlspecialchars($row['prix']);
            $vitesse = htmlspecialchars($row['vitesse']);
            $puissance = htmlspecialchars($row['puissance']);
            $imageBlob = !empty($row['image']) ? base64_encode($row['image']) : null;
            $nbvue = htmlspecialchars($row['nbvue']);

            echo "<tr>";
            echo "<td>" . $voitureId . "</td>";
            echo "<td>" . $marque . "</td>";
            echo "<td>" . $model . "</td>";
            echo "<td>" . $description . "</td>";
            echo "<td>" . $prix . "</td>";
            echo "<td>" . $vitesse . "</td>";
            echo "<td>" . $puissance . "</td>";
            echo "<td>" . $nbvue . "</td>";
            echo "<td>";
            if ($imageBlob) {
                echo "<img src='data:image/jpeg;base64,$imageBlob' alt='Image $voitureId' width='100'>";
            } else {
                echo "Aucune image";
            }
            echo "</td>";
            echo "<td>
                    <a href='edit.php?id=$voitureId'>Modifier</a> |
                    <a href='delete_car.php?id=$voitureId' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette voiture ?\")'>Supprimer</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='8'>Aucune voiture trouvée.</td></tr>";
    }
    ?>
</table>
<a href="/supercar/dashboard.php">Retour</a>

</body>
</html>

