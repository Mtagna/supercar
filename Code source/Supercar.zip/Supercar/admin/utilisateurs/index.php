<?php
// Including the database connection file
include_once("config.php");

// Fetching data in ascending order (id ASC)
$result = mysqli_query($bdd, "SELECT * FROM utilisateurs ORDER BY id ASC");
?>

<html>
<head>
    <title>Homepage</title>
</head>

<body>
    <p><u>Administration des utilisateurs</u></p>
	
    <table width="60%" border=0>
        <tr bgcolor="#CCCCCC">
            <td>ID</td>
            <td>Username</td>
            <td>Password</td>
            <td>Action</td>
        </tr>
		
        <?php 
        // Looping through the results and displaying them in the table
        while ($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['id']."</td>";
            echo "<td>".$res['identifiant']."</td>";
            echo "<td>".$res['password']."</td>";    
            echo "<td>
                    <a href=\"edit.php?id=$res[id]\">Edit</a> | 
                    <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a> 
                  </td>";       
            echo "</tr>";
        }
        ?>
    </table>
    <a href="/supercar/dashboard.php">Retour</a>
</body>
</html>
