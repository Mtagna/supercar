<?php
// including the database connection file
include_once("config.php");

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $identifiant = $_POST['identifiant'];
    $password = $_POST['password'];

    // checking empty fields
    if (empty($identifiant) || empty($password)) {
        if (empty($identifiant)) {
            echo "<font color='red'>Username field is empty.</font><br/>";
        }

        if (empty($password)) {
            echo "<font color='red'>Password field is empty.</font><br/>";
        }
    } else {
        // Encrypting the password if necessary (bcrypt)
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // updating the table
        $result = mysqli_query($bdd, "UPDATE utilisateurs SET identifiant='$identifiant', password='$hashedPassword' WHERE id=$id");

        // redirecting to the display page. In our case, it is index.php
        header("Location: index.php");
    }
}
?>

<?php
// getting id from URL
$id = $_GET['id'];

// selecting data associated with this particular id
$result = mysqli_query($bdd, "SELECT * FROM utilisateurs WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
    $identifiant = $res['identifiant'];
    $password = $res['password']; // Note: This will be the hashed password in the database
}
?>

<html>
<head>
    <title>Edit User</title>
</head>

<body>
    <a href="index.php">Home</a>
    <br/><br/>

    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr>
                <td>Username</td>
                <td><input type="text" name="identifiant" value="<?php echo $identifiant; ?>"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td>
                    <input type="password" name="password" placeholder="Enter new password">
                    <br><small>Leave empty to keep current password</small>
                </td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value="<?php echo $id; ?>"></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>
