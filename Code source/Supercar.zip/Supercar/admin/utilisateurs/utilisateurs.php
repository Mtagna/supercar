<?php
//including the database connection file
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");

 
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($bdd, "SELECT * FROM utilisateurs ORDER BY id ASC"); // using mysqli_query instead
?>
 
<html>
<head>    
    <title>Homepage</title>
    <style>
        /* Styles pour centrer le contenu */
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }

        /* Styles pour le paragraphe */
        p {
            margin-bottom: 20px;
            font-weight: bold;
            font-size: 1.5em;
            text-align: center;
        }

        /* Styles pour le tableau */
        table {
            border-collapse: collapse;
            width: 60%;
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        th {
            padding-top: 12px;
            padding-bottom: 12px;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
 
<body>
    <p>Gestion des utilisateurs</p>
	
    <table width="60%" border=0>
        <tr bgcolor="#CCCCCC">
			<td>ID</td>
            <td>Name</td>
            <td>Age</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
		
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
			echo "<td>".$res['id']."</td>";
            echo "<td>".$res['name']."</td>";
            echo "<td>".$res['age']."</td>";
            echo "<td>".$res['email']."</td>";    
            echo "<td>	<a href=\"edit.php?id=$res[id]\">Edit</a>   | 
						<a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";       
			echo "</tr>";
		}
        ?>
    </table>
    <a href= "/demandedessai/dashboard.php" >Retour </a>
</body>
</html>