<?php
// including the database connection file
include_once("config.php");
 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    $nom=$_POST['nom'];
    $email=$_POST['email'];  
    $objet=$_POST['objet'];
    $message=$_POST['message']; 
    
    // checking empty fields
    if(empty($nom) || empty($email) || empty($objet) || empty($message)) {            
        if(empty($nom)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        
        if(empty($email)) {
            echo "<font color='red'>Email field is empty.</font><br/>";
        }
        
        if(empty($objet)) {
            echo "<font color='red'>Objet field is empty.</font><br/>";
        }
        if(empty($message)) {
            echo "<font color='red'>Message field is empty.</font><br/>";
        }        
    } else {    
        //updating the table
        $result = mysqli_query($bdd, "UPDATE form SET nom='$nom',email='$email',objet='$objet',message='$message' WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: index.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($bdd, "SELECT * FROM form WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $nom = $res['nom'];
    $email = $res['email'];
    $objet = $res['objet'];
    $message = $res['message'];
}
?>
<html>
<head>    
    <title>Edit Data</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>Nom</td>
                <td><input type="text" name="nom" value="<?php echo $nom;?>"></td>
            </tr>
            <tr> 
                <td>Email</td>
                <td><input type="text" name="email" value="<?php echo $email;?>"></td>
            </tr>
            <tr> 
                <td>Objet</td>
                <td><input type="text" name="objet" value="<?php echo $objet;?>"></td>
            </tr>
            <tr>
                <td>Message</td>
                <td>
                    <textarea name="message" id="message" rows="5" cols="40" required><?php echo $message; ?></textarea>
                </td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>