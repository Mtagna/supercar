<?php
//including the database connection file
include_once("config.php");
 
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($bdd, "SELECT * FROM form ORDER BY id ASC"); // using mysqli_query instead
?>
 
<html>
<head>    
    <title>Homepage</title>
</head>
 
<body>
    <p><u> Administration de vos données </u></p>
	
    <table width="60%" border=0>
        <tr bgcolor="#CCCCCC">
			<td>ID</td>
            <td>Nom</td>
            <td>Email</td>
            <td>Objet</td>
            <td>Message</td>
            <td>Action</td>
        </tr>
		
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
			echo "<td>".$res['id']."</td>";
            echo "<td>".$res['nom']."</td>";
            echo "<td>".$res['email']."</td>";
            echo "<td>".$res['objet']."</td>";
            echo "<td>".$res['message']."</td>";    
            echo "<td>	<a href=\"edit.php?id=$res[id]\">Edit</a>   | 
						<a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a>   
                        </td>";       
			echo "</tr>";
		}
        ?>
    </table>
    <a href="/supercar/dashboard.php">Retour</a>
</body>
</html>