<?php
// Inclusion de la connexion à la base de données
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");

// Récupération des données de la table "demandes_essai"
$result = mysqli_query($bdd, "SELECT * FROM demandes_essai ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="fr">
<head>    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Demandes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            text-align: center;
        }

        table {
            border-collapse: collapse;
            width: 90%;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        .btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            color: white;
            border-radius: 4px;
        }

        .btn-confirm { background-color: #28a745; }
        .btn-complete { background-color: #007bff; }
        .btn-cancel { background-color: #dc3545; }

        .btn:hover {
            opacity: 0.8;
        }
    </style>
</head>

<body>
    <h2>Gestion des Demandes</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Utilisateur ID</th>
            <th>Marque</th>
            <th>Modèle</th>
            <th>Date</th>
            <th>Heure</th>
            <th>Téléphone</th>
            <th>Email</th>
            <th>Commentaire</th>
            <th>Date de Création</th>
            <th>Statut</th>
            <th>Actions</th>
        </tr>
        
        <?php 
        while($res = mysqli_fetch_assoc($result)) {         
            echo "<tr>";
            echo "<td>".$res['id']."</td>";
            echo "<td>".$res['user_id']."</td>";
            echo "<td>".$res['marque']."</td>";
            echo "<td>".$res['modele']."</td>";
            echo "<td>".$res['date']."</td>";
            echo "<td>".$res['heure']."</td>";
            echo "<td>".$res['telephone']."</td>";
            echo "<td>".$res['email']."</td>";
            echo "<td>".$res['commentaire']."</td>";    
            echo "<td>".$res['created_at']."</td>";  
            echo "<td id='status-".$res['id']."'>".$res['statut']."</td>"; 
            echo "<td>
                    <button class='btn btn-confirm' onclick=\"updateStatus(".$res['id'].", 'Confirmé')\">Confirmer</button>
                    <button class='btn btn-complete' onclick=\"updateStatus(".$res['id'].", 'Terminé')\">Terminer</button>
                    <button class='btn btn-cancel' onclick=\"updateStatus(".$res['id'].", 'Annulé')\">Annuler</button>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>

    <br>
    <a href="/supercar/dashboard.php">Retour au Tableau de Bord</a>

    <script>
        function updateStatus(id, statut) {
            fetch('update_statuts.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + id + '&statut=' + statut
            })
            .then(response => response.text())
            .then(data => {
                if (data === "success") {
                    document.getElementById('status-' + id).innerText = statut;
                } else {
                    alert("Erreur lors de la mise à jour du statut.");
                }
            });
        }
    </script>
</body>
</html>
