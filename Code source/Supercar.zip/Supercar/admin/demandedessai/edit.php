<?php
// Inclure la connexion à la base de données
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");

// Vérification si le formulaire est soumis
if (isset($_POST['update'])) {
    $id = intval($_POST['id']); // Sécurisation de l'ID
    $modele = mysqli_real_escape_string($bdd, trim($_POST['modele']));
    $user_id = mysqli_real_escape_string($bdd, trim($_POST['user_id']));
    $telephone = mysqli_real_escape_string($bdd, trim($_POST['telephone']));
    $email = mysqli_real_escape_string($bdd, trim($_POST['email']));
    $commentaire = mysqli_real_escape_string($bdd, trim($_POST['commentaire']));
    $statut = mysqli_real_escape_string($bdd, trim($_POST['statut']));

    // Vérification des champs vides
    if (empty($modele) || empty($user_id) || empty($telephone) || empty($email)) {
        echo "<font color='red'>Veuillez remplir tous les champs obligatoires.</font><br/>";
    } else {
        // Mise à jour des données avec le statut
        $query = "UPDATE demandes_essai SET 
                    modele='$modele', 
                    user_id='$user_id', 
                    telephone='$telephone', 
                    email='$email', 
                    commentaire='$commentaire',
                    statut='$statut'
                  WHERE id=$id";

        if (mysqli_query($bdd, $query)) {
            // Redirection après mise à jour
            header("Location: index.php");
            exit();
        } else {
            echo "<font color='red'>Erreur lors de la mise à jour : " . mysqli_error($bdd) . "</font>";
        }
    }
}

// Vérification et récupération de l'ID depuis l'URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = mysqli_query($bdd, "SELECT * FROM demandes_essai WHERE id=$id");

    if ($res = mysqli_fetch_assoc($result)) {
        $modele = $res['modele'];
        $user_id = $res['user_id'];
        $telephone = $res['telephone'];
        $email = $res['email'];
        $commentaire = $res['commentaire'];
        $statut = $res['statut']; // Récupérer le statut actuel
    } else {
        echo "<font color='red'>Aucune demande trouvée.</font>";
        exit();
    }
} else {
    echo "<font color='red'>ID invalide.</font>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Demande</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        a {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: #4CAF50;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Modifier la Demande</h2>

        <form method="post" action="edit.php">
            <label>Modèle :</label>
            <input type="text" name="modele" value="<?php echo htmlspecialchars($modele); ?>" required>

            <label>Utilisateur ID :</label>
            <input type="text" name="user_id" value="<?php echo htmlspecialchars($user_id); ?>" required>

            <label>Téléphone :</label> 
            <input type="text" name="telephone" value="<?php echo htmlspecialchars($telephone); ?>" required>

            <label>Email :</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>

            <label>Commentaires :</label>
            <textarea name="commentaire"><?php echo htmlspecialchars($commentaire); ?></textarea>

            <!-- Ajout du champ Statut -->
            <label>Statut :</label>
            <select name="statut">
                <option value="En attente" <?php if ($statut == 'En attente') echo "selected"; ?>>En attente</option>
                <option value="Confirmé" <?php if ($statut == 'Confirmé') echo "selected"; ?>>Confirmé</option>
                <option value="Terminé" <?php if ($statut == 'Terminé') echo "selected"; ?>>Terminé</option>
                <option value="Annulé" <?php if ($statut == 'Annulé') echo "selected"; ?>>Annulé</option>
            </select>

            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="submit" name="update" value="Mettre à jour">
        </form>

        <a href="index.php">Retour à l'accueil</a>
    </div>
</body>
</html>
