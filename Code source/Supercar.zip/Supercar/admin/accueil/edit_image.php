<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

// Mise à jour des données
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nom = $_POST['nom'];

    // Gestion de l'image si une nouvelle est téléchargée
    if (isset($_FILES['image']['tmp_name']) && !empty($_FILES['image']['tmp_name'])) {
        $imageData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
        $query = "UPDATE images SET nom='$nom', image='$imageData' WHERE id=$id";
    } else {
        // Mise à jour sans changer l'image
        $query = "UPDATE images SET nom='$nom' WHERE id=$id";
    }

    if (mysqli_query($bdd, $query)) {
        header("Location: index.php");
    } else {
        echo "<font color='red'>Erreur lors de la mise à jour : " . mysqli_error($bdd) . "</font>";
    }
}

// Récupération des données pour une entrée spécifique
$id = $_GET['id'];
$result = mysqli_query($bdd, "SELECT * FROM images WHERE id=$id");
$data = mysqli_fetch_assoc($result);

// Vérification si une image existe
$image = !empty($data['image']) ? base64_encode($data['image']) : null;
?>

<!DOCTYPE html>
<html lang="fr">
<head>    
    <title>Modifier une entrée</title>
</head>
<body>
    <a href="index.php">Retour à la liste</a>
    <br/><br/>
    
    <!-- Formulaire de modification -->
    <form name="form1" method="post" action="edit_image.php" enctype="multipart/form-data">
        <table border="0">
            <tr> 
                <td>Nom</td>
                <td><input type="text" name="nom" value="<?php echo htmlspecialchars($data['nom']); ?>"></td>
            </tr>
            <tr>
                <td>Image actuelle</td>
                <td>
                    <?php if ($image): ?>
                        <img src="data:image/jpeg;base64,<?php echo $image; ?>" alt="Image actuelle" width="100">
                    <?php else: ?>
                        Aucune image
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Nouvelle Image</td>
                <td><input type="file" name="image"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value="<?php echo $data['id']; ?>"></td>
                <td><input type="submit" name="update" value="Mettre à jour"></td>
            </tr>
        </table>
    </form>
</body>
</html>
