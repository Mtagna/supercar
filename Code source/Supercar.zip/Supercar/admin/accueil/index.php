<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "12345", "supercar");

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Définir le jeu de caractères
$conn->set_charset("utf8");
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Images</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<h2>Administration des Images</h2>

<table border="1" width="80%">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    <?php
    // Récupération de toutes les données de la table 'images'
    $resultImages = $conn->query("SELECT * FROM images");

    // Vérifier si des données existent
    if ($resultImages->num_rows > 0) {
        while ($row = $resultImages->fetch_assoc()) {
            $imageId = $row['id'];
            $nom = htmlspecialchars($row['nom']);
            $imageBlob = !empty($row['image']) ? base64_encode($row['image']) : null;

            echo "<tr>";
            echo "<td>" . $imageId . "</td>";
            echo "<td>" . $nom . "</td>";
            echo "<td>";
            if ($imageBlob) {
                echo "<img src='data:image/jpeg;base64,$imageBlob' alt='Image $imageId' width='100'>";
            } else {
                echo "Aucune image";
            }
            echo "</td>";
            echo "<td>
                    <a href='edit_image.php?id=$imageId'>Modifier</a> |
                    <a href='delete_image.php?id=$imageId' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette image ?\")'>Supprimer</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>Aucune image trouvée.</td></tr>";
    }
    ?>
</table>

<br><br>

<h2>Administration de la Description</h2>

<table width="60%" border="1">
    <tr bgcolor="#CCCCCC">
        <td>ID</td>
        <td>Type</td>
        <td>Nom</td>
        <td>Valeur</td>
        <td>Action</td>
    </tr>
    
    <?php
    // Requête pour récupérer les données de la table 'accueil1'
    $result = $conn->query("SELECT * FROM accueil1 ORDER BY id ASC");

    // Vérifier si des données existent
    if ($result->num_rows > 0) {
        while ($res = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $res['id'] . "</td>";
            echo "<td>" . htmlspecialchars($res['type']) . "</td>";
            echo "<td>" . htmlspecialchars($res['nom']) . "</td>";
            echo "<td>" . htmlspecialchars($res['valeur']) . "</td>";
            echo "<td>
                    <a href='edit.php?id=" . $res['id'] . "'>Modifier</a> |
                    <a href='delete.php?id=" . $res['id'] . "' onclick='return confirm(\"Voulez-vous vraiment supprimer cette entrée ?\")'>Supprimer</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>Aucune donnée trouvée.</td></tr>";
    }

    // Fermeture de la connexion
    $conn->close();
    ?>
</table>

<a href="/demandes_essai/dashboard.php">Retour</a>

</body>
</html>
