<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

if (isset($_POST['update'])) {    
    $id = $_POST['id'];
    $type = $_POST['type'];
    $nom = $_POST['nom'];  
    $valeur = $_POST['valeur'];
    
    // Vérifier les champs vides
    if (empty($type) || empty($nom) || empty($valeur)) {            
        if (empty($type)) {
            echo "<font color='red'>Le champ 'Type' est vide.</font><br/>";
        }
        
        if (empty($nom)) {
            echo "<font color='red'>Le champ 'Nom' est vide.</font><br/>";
        }
        
        if (empty($valeur)) {
            echo "<font color='red'>Le champ 'Valeur' est vide.</font><br/>";
        }        
    } else {    
        // Mettre à jour la table
        $result = mysqli_query($bdd, "UPDATE accueil1 SET type='$type', nom='$nom', valeur='$valeur' WHERE id=$id");
        
        // Rediriger vers la page d'affichage (index.php ou liste.php)
        header("Location: index.php");
    }
}
?>

<?php
// Récupérer l'identifiant depuis l'URL
$id = $_GET['id'];

// Sélectionner les données associées à cet identifiant
$result = mysqli_query($bdd, "SELECT * FROM accueil1 WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
    $type = $res['type'];
    $nom = $res['nom'];
    $valeur = $res['valeur'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>    
    <title>Modifier une entrée</title>
</head>

<body>
    <a href="index.php">Retour à la liste</a>
    <br/><br/>
    
    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>Type</td>
                <td><input type="text" name="type" value="<?php echo htmlspecialchars($type); ?>"></td>
            </tr>
            <tr> 
                <td>Nom</td>
                <td><input type="text" name="nom" value="<?php echo htmlspecialchars($nom); ?>"></td>
            </tr>
            <tr> 
                <td>Valeur</td>
                <td>
                    <textarea name="valeur" rows="5" cols="40" required><?php echo htmlspecialchars($valeur); ?></textarea>
                </td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value="<?php echo $id; ?>"></td>
                <td><input type="submit" name="update" value="Mettre à jour"></td>
            </tr>
        </table>
    </form>
</body>
</html>
