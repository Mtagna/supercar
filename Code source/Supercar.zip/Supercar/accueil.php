

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Car</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<header>
    <?php include 'index.php'; ?>
</header>
<br>
<br>
<br>

<!-- Conteneur du carrousel -->
<div class="carousel-container">
<?php
$conn = new mysqli("localhost", "root", "12345", "supercar");

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

$query = "SELECT id FROM images";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imageId = $row['id'];
        echo '<div class="carousel-slide fade">'; 
        echo '<img src="image.php?id=' . $imageId . '" alt="Image ' . $imageId . '">';
        echo '</div>';
    }
} else {
    echo "<p>Aucune image disponible pour le carrousel.</p>";
}

$conn->close();
?>

    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>

<!-- Points de navigation -->
<div class="dot-container">
<?php
$conn = new mysqli("localhost", "root", "12345", "supercar");

$query = "SELECT COUNT(*) as count FROM images";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $imageCount = $row['count'];
    for ($i = 1; $i <= $imageCount; $i++) {
        echo '<span class="dot" onclick="currentSlide(' . $i . ')"></span>'; // Un point par image
    }
}

$conn->close();
?>

</div>

<script>
    let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    let slides = document.getElementsByClassName("carousel-slide");
    let dots = document.getElementsByClassName("dot");

    // Réinitialiser l'index si nécessaire
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }

    // Masquer toutes les diapositives
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // Désactiver tous les points
    for (let i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }

    // Afficher la diapositive active
    slides[slideIndex - 1].style.display = "block";

    // Activer le point correspondant
    dots[slideIndex - 1].className += " active";
}

let autoIndex = 0;
autoShowSlides();

function autoShowSlides() {
    let slides = document.getElementsByClassName("carousel-slide");
    let dots = document.getElementsByClassName("dot");

    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    autoIndex++;
    if (autoIndex > slides.length) { autoIndex = 1 }

    slides[autoIndex - 1].style.display = "block";
    dots[autoIndex - 1].className += " active";

    setTimeout(autoShowSlides, 5000); // Change la diapositive toutes les 5 secondes
}

</script>

<section class="cta">
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "12345";
    $dbname = "supercar";

    $bdd = new mysqli($servername, $username, $password, $dbname);

    if ($bdd->connect_error) {
        die("Connexion échouée : " . $bdd->connect_error);
    }

    $bdd->set_charset("utf8");

    // Récupérer le titre et la description
    $query = "SELECT nom, valeur FROM accueil1 WHERE nom IN ('Titre(h2)', 'description supercar')";
    $curseur = mysqli_query($bdd, $query);

    if ($curseur) {
        $data = [];
        while ($row = mysqli_fetch_array($curseur, MYSQLI_ASSOC)) {
            $data[$row['nom']] = $row['valeur'];
        }

        // Afficher le titre
        if (isset($data['Titre(h2)'])) {
            echo "<h2>" . htmlspecialchars($data['Titre(h2)']) . "</h2>";
        } else {
            echo "<h2>Titre non disponible</h2>";
        }

        // Afficher la description
        if (isset($data['description supercar'])) {
            echo "<p>" . htmlspecialchars($data['description supercar']) . "</p>";
        } else {
            echo "<p>Description non disponible</p>";
        }
    } else {
        echo "Erreur dans la requête SQL : " . $bdd->error;
    }

    $bdd->close();
    ?>
    <hr>
    <a href="voitures.php">Explorez notre collection</a>
</section>
<br>
<?php include 'footer.html'; ?>
